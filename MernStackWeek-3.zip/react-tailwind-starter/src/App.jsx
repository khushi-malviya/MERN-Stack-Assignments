import TextUpdater from './components/TextUpdater';
import SimpleForm from './components/SimpleForm';
import UserCard from './components/UserCard';
import CustomButton from './components/CustomButton';
import LoginForm from './components/LoginForm';

function App() {
  return (
    <div className="min-h-screen flex flex-col items-center justify-center gap-8 bg-gray-100 p-4">
      <h1 className="text-3xl font-bold text-blue-600">MERN Week 3 Assignment</h1>
      <TextUpdater />
      <SimpleForm />
      <UserCard name="Khushi Malviya" email="khushimalviya2022@vitbhopal.ac.in" />
      <CustomButton />
      <LoginForm />    
    </div>
  );
}

export default App;
