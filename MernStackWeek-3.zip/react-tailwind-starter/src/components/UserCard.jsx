import React from 'react';

function UserCard({ name, email }) {
  return (
    <div className="bg-white shadow-md rounded p-4 max-w-md mx-auto border">
      <h2 className="text-xl font-semibold text-gray-800">{name}</h2>
      <p className="text-gray-600">{email}</p>
    </div>
  );
}

export default UserCard;
