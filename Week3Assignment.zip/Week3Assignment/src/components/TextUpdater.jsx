import React, { useState } from 'react';

function TextUpdater() {
  const [text, setText] = useState('');

  return (
    <div className="p-4 max-w-md mx-auto bg-white rounded shadow">
      <input 
        type="text" 
        value={text}
        onChange={(e) => setText(e.target.value)}
        className="w-full p-2 border rounded mb-2"
        placeholder="Type something..."
      />
      <p className="text-gray-700">You typed: {text}</p>
    </div>
  );
}

export default TextUpdater;
